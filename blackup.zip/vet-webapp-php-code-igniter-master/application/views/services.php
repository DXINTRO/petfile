   <div class="jumbotron" id="about">
       
 <h1>Services Offered</h1>
      </div>

      <!-- Example row of columns -->
       <div class="row">
        <div class="col-lg-4">
          <center><h2>Grooming</h2></center>
            <img  style=" width:330px; height:200px;" src="<?php echo base_url();?>assets/images/dog_grooming_in_des_moines.jpg">
         
        </div>
        <div class="col-lg-4">
         <center><h2>Check up</h2></center>
            <img  style=" width:330px; height:200px;" src="<?php echo base_url();?>assets/images/1382323177138.jpg">
       </div>
        <div class="col-lg-4">
          <center><h2>Operations</h2></center>
            <img  style=" width:330px; height:200px;" src="<?php echo base_url();?>assets/images/download.jpg">
        </div>
      </div>
      <div class="footer" style="text-align:center;">
        <p>&copy; Vets In Practice 2013</p>
      </div>