 <div class="header">
        <ul class="nav nav-pills pull-right userNavbar">
          <li class="navReserve"><a href="<?php echo base_url(); ?>user">Reserve</a></li>
          <li class="navOrder"><a href="<?php echo base_url(); ?>user/order">Order</a></li>
          <li class="navViewCart"><a href="<?php echo base_url(); ?>user/viewCart">View Cart</a></li>
          <li class="navReserveManage"><a href="<?php echo base_url(); ?>user/manageReservation">Manage Reservations</a></li>
          <!-- <li class="navEditProfile"><a href="#">Edit Profile</a></li> -->
          <li><a href="<?php echo base_url(); ?>user/logout">Log-Out</a></li>
        </ul>
        <h3 class="text-muted">Vets in Practice</h3>
</div>