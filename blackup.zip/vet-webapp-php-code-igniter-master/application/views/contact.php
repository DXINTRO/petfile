   <div class="jumbotron" id="about">
       
 <h1>Contact Us</h1>
 <table align="center">
 <tr>
 <td><h3>Email: </h3></td> <td><h3>vetsinpractice@gmail.com</h3></td>
 </tr>
 <tr>
 <td><h3>Telephone: </h3></td> <td><h3>531 - 2354</h3></td>
 </tr>
 <tr> <td> <h3>Address: </h3></td> <td><h4><p>	63 Maysilo Circle cor. Boni Ave. Mandaluyong, Philippines phone 531-1581</p></h4></td></tr>
 </table>

      </div>

      <!-- Example row of columns -->
       <div class="row">
        <div class="col-lg-4">
          <center><h2>Grooming</h2></center>
            <img  style=" width:330px; height:200px;" src="<?php echo base_url();?>assets/images/dog_grooming_in_des_moines.jpg">
        </div>
        <div class="col-lg-4">
         <center><h2>Check up</h2></center>
            <img  style=" width:330px; height:200px;" src="<?php echo base_url();?>assets/images/1382323177138.jpg">
       </div>
        <div class="col-lg-4">
          <center><h2>Operations</h2></center>
            <img  style=" width:330px; height:200px;" src="<?php echo base_url();?>assets/images/download.jpg">
        </div>
      </div>
      <div class="footer" style="text-align:center;">
        <p>&copy; Vets In Practice 2013</p>
      </div>