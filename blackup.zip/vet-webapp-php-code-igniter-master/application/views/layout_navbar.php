 <div class="masthead">
 <table>
 <tr>
 <td>
  <img style="width:100px;" src="<?php echo base_url();?>assets/images/logo.jpg"></td>
  <td>	   <h1 style="margin:10px 0px;">Vets In Practice</h1></td>
  <td></td>
 </tr>
 </table>
      

        <ul class="nav nav-justified navMainLayout">
          <li id="navHome"><a href="<?php echo base_url();?>">Home</a></li>
          <li><a href="<?php echo base_url();?>about">About</a></li>
          <li><a href="<?php echo base_url();?>services">Services</a></li>
          <li><a href="<?php echo base_url();?>contact">Contact</a></li>
          <li id="navSignin"><a href="<?php echo base_url();?>signin">Sign-In</a></li>
          <li id="navUserRegister"><a href="<?php echo base_url();?>registration">Register</a></li>
        </ul>
  </div>