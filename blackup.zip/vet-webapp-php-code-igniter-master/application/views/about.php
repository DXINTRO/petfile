   <div class="jumbotron" id="about">
   
        <h1>Vets In Practice</h1>
 <h3>About The Company</h3>
      </div>

      <!-- Example row of columns -->
      <div class="row">
   
        <div style="text-align:justify;">
      <p align="center"><h3>VIP pet hotel and wellness center started 7 years ago as a small vet clinic in Mandaluyong. The first reason for opening this place was post-operative care, Dr. Marga Carpio, veterinarian and VIPs resident natural therapy advocate, who directs the wellness center. VIP Pet Hotel and Wellness Center are able to deliver one of the best services to our patients because of thorough examination and treatment aided by state-of-the-art equipment, facilities and specialist-affiliations, including in Diagnostics like Blood Counting and Blood Chemistry Machine, X-Ray, Ultrasound, Electrocardiogram, Fiber-Optic Endoscopy, In-House Laboratory Unit. In Surgery from basic Soft Tissue Procedures, Orthodontics, Orthopedics and Ophthalmic procedures aided by the safest and modern anesthetic agents and equipment. In Treatment & Confinement like in-house Pharmacy, hygieneic stainless steel holding cages, incubator, whelping suite manned 24-hours by the vets and technicians.</h3></p>
       </div>
  
      </div>
      <div class="footer" style="text-align:center;">
        <p>&copy; Vets In Practice 2013</p>
      </div>